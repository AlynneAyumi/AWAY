interface RelatorioGeral {
    void gerarRelatorio();
}
